﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CIS_317_Calculator_Project
{
    public partial class Form1 : Form
    { 
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        decimal memory, num;        
        decimal total, difference, product, mod;
        int option;

        
        private void zeroButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = displayLabel.Text + "0";
        }
       
        private void oneButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = displayLabel.Text + "1";
        }

        private void twoButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = displayLabel.Text + "2";
        }

        private void threeButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = displayLabel.Text + "3";
        }

        private void fourButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = displayLabel.Text + "4";
        }

        private void fiveButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = displayLabel.Text + "5";
        }

        private void sixButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = displayLabel.Text + "6";
        }

        private void sevenButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = displayLabel.Text + "7";
        }

        private void eightButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = displayLabel.Text + "8";
        }

        private void nineButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = displayLabel.Text + "9";
        }

        private void decimalButton_Click(object sender, EventArgs e)
        {


            if (!displayLabel.Text.Contains("."))
            {
                displayLabel.Text = displayLabel.Text + ".";
            }
        }
        private void clearButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = " ";
           
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            total += Convert.ToDecimal(displayLabel.Text);
            displayLabel.Text = " ";
            option = 1;
        }

        private void minusButton_Click(object sender, EventArgs e)
        {
            difference = Convert.ToDecimal(displayLabel.Text);
            displayLabel.Text = "";
            option = 2;
        }

        private void memoryButton_Click(object sender, EventArgs e)
        {
            memory = Convert.ToDecimal(displayLabel.Text);
        }

        private void memoryRecallButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = Convert.ToString(memory);
        }

        private void timesButton_Click(object sender, EventArgs e)
        {
            product = Convert.ToDecimal(displayLabel.Text);
            displayLabel.Text = "";
            option = 3;
        }

        private void memoryClearButton_Click(object sender, EventArgs e)
        {
            memory = 0;
            displayLabel.Text = " ";
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //displayLabel.Text += (char) e.KeyCode;
        }

        private void clearEverythingButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = " ";
            memory = 0;
        }

        private void divisionButton_Click(object sender, EventArgs e)
        {


            //if (mod == 0)
            //{
            num = Convert.ToDecimal(displayLabel.Text);
            option = 4;
            displayLabel.Text = "";
            //}
            //else
            //{
            //    displayLabel.Text = "Error";
            //    displayLabel.Text = " ";
            //}


        }

       
        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
             //displayLabel.Text += (char) e.KeyChar;
        }

        private void equalsButton_Click(object sender, EventArgs e)
        {
            
            switch (option)
            {
                case 1:
                    //total = total;
                    total = total + Convert.ToDecimal(displayLabel.Text);                    
                    displayLabel.Text = Convert.ToString(total);
                    total = 0;
                    break;
                case 2:
                    difference = difference - Convert.ToDecimal(displayLabel.Text);
                    displayLabel.Text = Convert.ToString(difference);
                    difference = 0;
                    break;
                case 3:
                    product = product * Convert.ToDecimal(displayLabel.Text);
                    displayLabel.Text = Convert.ToString(product);
                    product = 0;
                    break;
                case 4:
                    bool continueLoop = true;

                    do
                    {
                        try
                        {
                            mod = Convert.ToDecimal(displayLabel.Text);

                            mod = num / mod;
                            displayLabel.Text = Convert.ToString(mod);
                            mod = 0;
                            continueLoop = false;
                        }
                        catch (FormatException)
                        {
                            displayLabel.Text = "Error";
                            MessageBox.Show("Use a numerical value", "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                            displayLabel.Text = " ";
                            break;

                        }
                        catch (DivideByZeroException)
                        {
                            displayLabel.Text = "Error";
                            
                            MessageBox.Show("Can not divide by zero" , "Error", MessageBoxButtons.OK ,
                                MessageBoxIcon.Error);
                            displayLabel.Text = " ";
                            break;
                        }
                                               
                    }
                    while (continueLoop);
                      break;

                        default:
                             break;  
                  }
                 
        }
    }
}
