﻿namespace CIS_317_Calculator_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.oneButton = new System.Windows.Forms.Button();
            this.twoButton = new System.Windows.Forms.Button();
            this.threeButton = new System.Windows.Forms.Button();
            this.fourButton = new System.Windows.Forms.Button();
            this.fiveButton = new System.Windows.Forms.Button();
            this.sixButton = new System.Windows.Forms.Button();
            this.sevenButton = new System.Windows.Forms.Button();
            this.displayLabel = new System.Windows.Forms.Label();
            this.eightButton = new System.Windows.Forms.Button();
            this.nineButton = new System.Windows.Forms.Button();
            this.zeroButton = new System.Windows.Forms.Button();
            this.decimalButton = new System.Windows.Forms.Button();
            this.equalsButton = new System.Windows.Forms.Button();
            this.memoryButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.clearEverythingButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.minusButton = new System.Windows.Forms.Button();
            this.timesButton = new System.Windows.Forms.Button();
            this.divisionButton = new System.Windows.Forms.Button();
            this.memoryRecallButton = new System.Windows.Forms.Button();
            this.memoryClearButton = new System.Windows.Forms.Button();
            this.mottoTextBox = new System.Windows.Forms.TextBox();
            this.logoPicBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBox)).BeginInit();
            this.SuspendLayout();
            // 
            // oneButton
            // 
            this.oneButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.oneButton.Location = new System.Drawing.Point(40, 565);
            this.oneButton.Margin = new System.Windows.Forms.Padding(4);
            this.oneButton.Name = "oneButton";
            this.oneButton.Size = new System.Drawing.Size(85, 72);
            this.oneButton.TabIndex = 0;
            this.oneButton.Text = "1";
            this.oneButton.UseVisualStyleBackColor = false;
            this.oneButton.Click += new System.EventHandler(this.oneButton_Click);
            // 
            // twoButton
            // 
            this.twoButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.twoButton.Location = new System.Drawing.Point(155, 565);
            this.twoButton.Margin = new System.Windows.Forms.Padding(4);
            this.twoButton.Name = "twoButton";
            this.twoButton.Size = new System.Drawing.Size(85, 72);
            this.twoButton.TabIndex = 2;
            this.twoButton.Text = "2";
            this.twoButton.UseVisualStyleBackColor = false;
            this.twoButton.Click += new System.EventHandler(this.twoButton_Click);
            // 
            // threeButton
            // 
            this.threeButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.threeButton.Location = new System.Drawing.Point(265, 565);
            this.threeButton.Margin = new System.Windows.Forms.Padding(4);
            this.threeButton.Name = "threeButton";
            this.threeButton.Size = new System.Drawing.Size(85, 72);
            this.threeButton.TabIndex = 3;
            this.threeButton.Text = "3";
            this.threeButton.UseVisualStyleBackColor = false;
            this.threeButton.Click += new System.EventHandler(this.threeButton_Click);
            // 
            // fourButton
            // 
            this.fourButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.fourButton.Location = new System.Drawing.Point(40, 432);
            this.fourButton.Margin = new System.Windows.Forms.Padding(4);
            this.fourButton.Name = "fourButton";
            this.fourButton.Size = new System.Drawing.Size(85, 72);
            this.fourButton.TabIndex = 4;
            this.fourButton.Text = "4";
            this.fourButton.UseVisualStyleBackColor = false;
            this.fourButton.Click += new System.EventHandler(this.fourButton_Click);
            // 
            // fiveButton
            // 
            this.fiveButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.fiveButton.Location = new System.Drawing.Point(155, 432);
            this.fiveButton.Margin = new System.Windows.Forms.Padding(4);
            this.fiveButton.Name = "fiveButton";
            this.fiveButton.Size = new System.Drawing.Size(85, 72);
            this.fiveButton.TabIndex = 5;
            this.fiveButton.Text = "5";
            this.fiveButton.UseVisualStyleBackColor = false;
            this.fiveButton.Click += new System.EventHandler(this.fiveButton_Click);
            // 
            // sixButton
            // 
            this.sixButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.sixButton.Location = new System.Drawing.Point(265, 432);
            this.sixButton.Margin = new System.Windows.Forms.Padding(4);
            this.sixButton.Name = "sixButton";
            this.sixButton.Size = new System.Drawing.Size(85, 72);
            this.sixButton.TabIndex = 6;
            this.sixButton.Text = "6";
            this.sixButton.UseVisualStyleBackColor = false;
            this.sixButton.Click += new System.EventHandler(this.sixButton_Click);
            // 
            // sevenButton
            // 
            this.sevenButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.sevenButton.Location = new System.Drawing.Point(40, 302);
            this.sevenButton.Margin = new System.Windows.Forms.Padding(4);
            this.sevenButton.Name = "sevenButton";
            this.sevenButton.Size = new System.Drawing.Size(85, 72);
            this.sevenButton.TabIndex = 7;
            this.sevenButton.Text = "7";
            this.sevenButton.UseVisualStyleBackColor = false;
            this.sevenButton.Click += new System.EventHandler(this.sevenButton_Click);
            // 
            // displayLabel
            // 
            this.displayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayLabel.Font = new System.Drawing.Font("Monotype Corsiva", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayLabel.Location = new System.Drawing.Point(40, 65);
            this.displayLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(579, 71);
            this.displayLabel.TabIndex = 8;
            this.displayLabel.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // eightButton
            // 
            this.eightButton.BackColor = System.Drawing.Color.White;
            this.eightButton.Location = new System.Drawing.Point(155, 302);
            this.eightButton.Margin = new System.Windows.Forms.Padding(4);
            this.eightButton.Name = "eightButton";
            this.eightButton.Size = new System.Drawing.Size(85, 72);
            this.eightButton.TabIndex = 9;
            this.eightButton.Text = "8";
            this.eightButton.UseVisualStyleBackColor = false;
            this.eightButton.Click += new System.EventHandler(this.eightButton_Click);
            // 
            // nineButton
            // 
            this.nineButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.nineButton.Location = new System.Drawing.Point(265, 302);
            this.nineButton.Margin = new System.Windows.Forms.Padding(4);
            this.nineButton.Name = "nineButton";
            this.nineButton.Size = new System.Drawing.Size(85, 72);
            this.nineButton.TabIndex = 10;
            this.nineButton.Text = "9";
            this.nineButton.UseVisualStyleBackColor = false;
            this.nineButton.Click += new System.EventHandler(this.nineButton_Click);
            // 
            // zeroButton
            // 
            this.zeroButton.BackColor = System.Drawing.SystemColors.HighlightText;
            this.zeroButton.Location = new System.Drawing.Point(40, 685);
            this.zeroButton.Margin = new System.Windows.Forms.Padding(4);
            this.zeroButton.Name = "zeroButton";
            this.zeroButton.Size = new System.Drawing.Size(85, 72);
            this.zeroButton.TabIndex = 11;
            this.zeroButton.Text = "0";
            this.zeroButton.UseVisualStyleBackColor = false;
            this.zeroButton.Click += new System.EventHandler(this.zeroButton_Click);
            this.zeroButton.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            // 
            // decimalButton
            // 
            this.decimalButton.Location = new System.Drawing.Point(155, 685);
            this.decimalButton.Margin = new System.Windows.Forms.Padding(4);
            this.decimalButton.Name = "decimalButton";
            this.decimalButton.Size = new System.Drawing.Size(85, 72);
            this.decimalButton.TabIndex = 12;
            this.decimalButton.Text = ".";
            this.decimalButton.UseVisualStyleBackColor = true;
            this.decimalButton.Click += new System.EventHandler(this.decimalButton_Click);
            // 
            // equalsButton
            // 
            this.equalsButton.BackColor = System.Drawing.Color.PeachPuff;
            this.equalsButton.Location = new System.Drawing.Point(265, 685);
            this.equalsButton.Margin = new System.Windows.Forms.Padding(4);
            this.equalsButton.Name = "equalsButton";
            this.equalsButton.Size = new System.Drawing.Size(85, 72);
            this.equalsButton.TabIndex = 13;
            this.equalsButton.Text = "=";
            this.equalsButton.UseVisualStyleBackColor = false;
            this.equalsButton.Click += new System.EventHandler(this.equalsButton_Click);
            // 
            // memoryButton
            // 
            this.memoryButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.memoryButton.Location = new System.Drawing.Point(40, 163);
            this.memoryButton.Margin = new System.Windows.Forms.Padding(4);
            this.memoryButton.Name = "memoryButton";
            this.memoryButton.Size = new System.Drawing.Size(85, 84);
            this.memoryButton.TabIndex = 14;
            this.memoryButton.Text = "MS";
            this.memoryButton.UseVisualStyleBackColor = false;
            this.memoryButton.Click += new System.EventHandler(this.memoryButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.BackColor = System.Drawing.Color.Yellow;
            this.clearButton.Location = new System.Drawing.Point(380, 163);
            this.clearButton.Margin = new System.Windows.Forms.Padding(4);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(109, 84);
            this.clearButton.TabIndex = 15;
            this.clearButton.Text = "C";
            this.clearButton.UseVisualStyleBackColor = false;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // clearEverythingButton
            // 
            this.clearEverythingButton.BackColor = System.Drawing.Color.Yellow;
            this.clearEverythingButton.Location = new System.Drawing.Point(511, 163);
            this.clearEverythingButton.Margin = new System.Windows.Forms.Padding(4);
            this.clearEverythingButton.Name = "clearEverythingButton";
            this.clearEverythingButton.Size = new System.Drawing.Size(109, 84);
            this.clearEverythingButton.TabIndex = 16;
            this.clearEverythingButton.Text = "CE";
            this.clearEverythingButton.UseVisualStyleBackColor = false;
            this.clearEverythingButton.Click += new System.EventHandler(this.clearEverythingButton_Click);
            // 
            // addButton
            // 
            this.addButton.BackColor = System.Drawing.Color.Aqua;
            this.addButton.Location = new System.Drawing.Point(380, 302);
            this.addButton.Margin = new System.Windows.Forms.Padding(4);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(240, 72);
            this.addButton.TabIndex = 17;
            this.addButton.Text = "+";
            this.addButton.UseVisualStyleBackColor = false;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // minusButton
            // 
            this.minusButton.BackColor = System.Drawing.Color.Coral;
            this.minusButton.Location = new System.Drawing.Point(380, 432);
            this.minusButton.Margin = new System.Windows.Forms.Padding(4);
            this.minusButton.Name = "minusButton";
            this.minusButton.Size = new System.Drawing.Size(240, 72);
            this.minusButton.TabIndex = 18;
            this.minusButton.Text = "-";
            this.minusButton.UseVisualStyleBackColor = false;
            this.minusButton.Click += new System.EventHandler(this.minusButton_Click);
            // 
            // timesButton
            // 
            this.timesButton.BackColor = System.Drawing.Color.SkyBlue;
            this.timesButton.Location = new System.Drawing.Point(380, 565);
            this.timesButton.Margin = new System.Windows.Forms.Padding(4);
            this.timesButton.Name = "timesButton";
            this.timesButton.Size = new System.Drawing.Size(240, 72);
            this.timesButton.TabIndex = 19;
            this.timesButton.Text = "*";
            this.timesButton.UseVisualStyleBackColor = false;
            this.timesButton.Click += new System.EventHandler(this.timesButton_Click);
            // 
            // divisionButton
            // 
            this.divisionButton.BackColor = System.Drawing.Color.Orchid;
            this.divisionButton.Location = new System.Drawing.Point(380, 685);
            this.divisionButton.Margin = new System.Windows.Forms.Padding(4);
            this.divisionButton.Name = "divisionButton";
            this.divisionButton.Size = new System.Drawing.Size(240, 72);
            this.divisionButton.TabIndex = 20;
            this.divisionButton.Text = "/";
            this.divisionButton.UseVisualStyleBackColor = false;
            this.divisionButton.Click += new System.EventHandler(this.divisionButton_Click);
            // 
            // memoryRecallButton
            // 
            this.memoryRecallButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.memoryRecallButton.Location = new System.Drawing.Point(155, 163);
            this.memoryRecallButton.Margin = new System.Windows.Forms.Padding(4);
            this.memoryRecallButton.Name = "memoryRecallButton";
            this.memoryRecallButton.Size = new System.Drawing.Size(85, 84);
            this.memoryRecallButton.TabIndex = 21;
            this.memoryRecallButton.Text = "MR";
            this.memoryRecallButton.UseVisualStyleBackColor = false;
            this.memoryRecallButton.Click += new System.EventHandler(this.memoryRecallButton_Click);
            // 
            // memoryClearButton
            // 
            this.memoryClearButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.memoryClearButton.Location = new System.Drawing.Point(265, 163);
            this.memoryClearButton.Margin = new System.Windows.Forms.Padding(4);
            this.memoryClearButton.Name = "memoryClearButton";
            this.memoryClearButton.Size = new System.Drawing.Size(85, 84);
            this.memoryClearButton.TabIndex = 22;
            this.memoryClearButton.Text = "MC";
            this.memoryClearButton.UseVisualStyleBackColor = false;
            this.memoryClearButton.Click += new System.EventHandler(this.memoryClearButton_Click);
            // 
            // mottoTextBox
            // 
            this.mottoTextBox.BackColor = System.Drawing.SystemColors.Window;
            this.mottoTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mottoTextBox.Font = new System.Drawing.Font("Monotype Corsiva", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mottoTextBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.mottoTextBox.Location = new System.Drawing.Point(652, 371);
            this.mottoTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.mottoTextBox.Multiline = true;
            this.mottoTextBox.Name = "mottoTextBox";
            this.mottoTextBox.Size = new System.Drawing.Size(284, 324);
            this.mottoTextBox.TabIndex = 24;
            this.mottoTextBox.Text = "Aerie\'s Help Seekers:\r\n\"Working to provide the\r\nhelp that you need!\"";
            this.mottoTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // logoPicBox
            // 
            this.logoPicBox.Image = global::CIS_317_Calculator_Project.Properties.Resources.IMG_2639;
            this.logoPicBox.Location = new System.Drawing.Point(664, 65);
            this.logoPicBox.Margin = new System.Windows.Forms.Padding(4);
            this.logoPicBox.Name = "logoPicBox";
            this.logoPicBox.Size = new System.Drawing.Size(272, 253);
            this.logoPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoPicBox.TabIndex = 23;
            this.logoPicBox.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(977, 820);
            this.Controls.Add(this.mottoTextBox);
            this.Controls.Add(this.logoPicBox);
            this.Controls.Add(this.memoryClearButton);
            this.Controls.Add(this.memoryRecallButton);
            this.Controls.Add(this.divisionButton);
            this.Controls.Add(this.timesButton);
            this.Controls.Add(this.minusButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.clearEverythingButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.memoryButton);
            this.Controls.Add(this.equalsButton);
            this.Controls.Add(this.decimalButton);
            this.Controls.Add(this.zeroButton);
            this.Controls.Add(this.nineButton);
            this.Controls.Add(this.eightButton);
            this.Controls.Add(this.displayLabel);
            this.Controls.Add(this.sevenButton);
            this.Controls.Add(this.sixButton);
            this.Controls.Add(this.fiveButton);
            this.Controls.Add(this.fourButton);
            this.Controls.Add(this.threeButton);
            this.Controls.Add(this.twoButton);
            this.Controls.Add(this.oneButton);
            this.Font = new System.Drawing.Font("Monotype Corsiva", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Aerie\'s Help Seeker\'s Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button oneButton;
        private System.Windows.Forms.Button twoButton;
        private System.Windows.Forms.Button threeButton;
        private System.Windows.Forms.Button fourButton;
        private System.Windows.Forms.Button fiveButton;
        private System.Windows.Forms.Button sixButton;
        private System.Windows.Forms.Button sevenButton;
        private System.Windows.Forms.Label displayLabel;
        private System.Windows.Forms.Button eightButton;
        private System.Windows.Forms.Button nineButton;
        private System.Windows.Forms.Button zeroButton;
        private System.Windows.Forms.Button decimalButton;
        private System.Windows.Forms.Button equalsButton;
        private System.Windows.Forms.Button memoryButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button clearEverythingButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button minusButton;
        private System.Windows.Forms.Button timesButton;
        private System.Windows.Forms.Button divisionButton;
        private System.Windows.Forms.Button memoryRecallButton;
        private System.Windows.Forms.Button memoryClearButton;
        private System.Windows.Forms.PictureBox logoPicBox;
        private System.Windows.Forms.TextBox mottoTextBox;
    }
}

